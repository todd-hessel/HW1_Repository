package oit.cst420.helloandroid;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Button b = null;
	private CheckBox c = null;
	private RatingBar r = null;
	private Button b2 = null;
	private SeekBar s = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		b = (Button) findViewById(R.id.myButton);
		c = (CheckBox) findViewById(R.id.checkBox1);
		r = (RatingBar) findViewById(R.id.ratingBar1);
		b2 = (Button) findViewById(R.id.button2);
		s = (SeekBar) findViewById(R.id.seekBar1);

		// create a listener - watch for the check box to be checked - if the
		// box is checked show the button
		c.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				if (isChecked == true) {
					b.setVisibility(android.view.View.VISIBLE);
				}
				if (isChecked == false) {
					b.setVisibility(android.view.View.INVISIBLE);
				}
			}
		});

		// create a listener - watch for the button to be pressed - if the
		// button is pressed raise the rating
		b.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (r.getRating() < 5) {
					r.setRating(r.getRating() + 1);
				} else {
					Toast.makeText(MainActivity.this, "WOO~!", Toast.LENGTH_SHORT).show();
					s.setProgress(s.getProgress() + 10);
				}
			}
		});

		// create a scroll-value listener (( or something )) - at 100% enable
		// the button
		s.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				if (s.getProgress() == 100) {
					b2.setEnabled(true);
				} else {
					b2.setEnabled(false);
				}
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub

			}
		});

		// create a listener - watch for the button to be pressed - if the
		// button is pressed reset the slider/stars
		b2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				r.setRating(0);
				s.setProgress(0);
				c.setChecked(false);
			}
		});
	}

}
