/** Automatically generated file. DO NOT MODIFY */
package oit.cst420.helloandroid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}